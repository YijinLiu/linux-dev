var base_8h =
[
    [ "id", "classcl_1_1sycl_1_1id.html", null ],
    [ "nd_range", "classcl_1_1sycl_1_1nd__range.html", "classcl_1_1sycl_1_1nd__range" ],
    [ "item", "classcl_1_1sycl_1_1item.html", "classcl_1_1sycl_1_1item" ],
    [ "nd_item", "classcl_1_1sycl_1_1nd__item.html", "classcl_1_1sycl_1_1nd__item" ],
    [ "group", "classcl_1_1sycl_1_1group.html", "classcl_1_1sycl_1_1group" ],
    [ "range", "classcl_1_1sycl_1_1range.html", "classcl_1_1sycl_1_1range" ],
    [ "address_space", "base_8h.html#a0b32461aa4a1867f288b640d7fc64fbf", [
      [ "private_space", "base_8h.html#a0b32461aa4a1867f288b640d7fc64fbfa9c3fa85807d489cc15cbbef1fcc1f9b0", null ],
      [ "global_space", "base_8h.html#a0b32461aa4a1867f288b640d7fc64fbfa8b6e19b80779e1f75b1c5f54a800dca4", null ],
      [ "constant_space", "base_8h.html#a0b32461aa4a1867f288b640d7fc64fbfac7a17f9f56c653a22f0e5cb25b241aeb", null ],
      [ "local_space", "base_8h.html#a0b32461aa4a1867f288b640d7fc64fbfa619fb1f3a892c810ac284e01782c8531", null ]
    ] ],
    [ "fence_space", "base_8h.html#a1e26dc60d7c93fcc056d6be0c41d1d42", [
      [ "local_space", "base_8h.html#a1e26dc60d7c93fcc056d6be0c41d1d42a619fb1f3a892c810ac284e01782c8531", null ],
      [ "global_space", "base_8h.html#a1e26dc60d7c93fcc056d6be0c41d1d42a8b6e19b80779e1f75b1c5f54a800dca4", null ],
      [ "global_and_local", "base_8h.html#a1e26dc60d7c93fcc056d6be0c41d1d42a78877b2c21d50a8878a02d10f4a79a3b", null ]
    ] ]
];