var searchData=
[
  ['placeholder',['placeholder',['../namespacecl_1_1sycl_1_1codeplay_1_1access.html#a6789b62da3b1db535905108006ac9852',1,'cl::sycl::codeplay::access']]],
  ['platform',['platform',['../namespacecl_1_1sycl_1_1info.html#a3ea7e38ccbc7de5270c4f69bbae20463',1,'cl::sycl::info']]],
  ['program',['program',['../namespacecl_1_1sycl_1_1info.html#a6645cc5581516494ff2409d887258574',1,'cl::sycl::info']]]
];
