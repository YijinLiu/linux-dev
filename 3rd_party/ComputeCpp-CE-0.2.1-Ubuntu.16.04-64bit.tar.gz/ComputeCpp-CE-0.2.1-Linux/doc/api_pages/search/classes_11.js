var searchData=
[
  ['vec',['vec',['../classcl_1_1sycl_1_1vec.html',1,'cl::sycl']]]
];
