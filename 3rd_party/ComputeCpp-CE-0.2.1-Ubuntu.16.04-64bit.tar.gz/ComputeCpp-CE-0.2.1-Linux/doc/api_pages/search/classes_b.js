var searchData=
[
  ['nd_5fitem',['nd_item',['../classcl_1_1sycl_1_1nd__item.html',1,'cl::sycl']]],
  ['nd_5frange',['nd_range',['../classcl_1_1sycl_1_1nd__range.html',1,'cl::sycl']]],
  ['nd_5frange_5ferror',['nd_range_error',['../classcl_1_1sycl_1_1nd__range__error.html',1,'cl::sycl']]]
];
