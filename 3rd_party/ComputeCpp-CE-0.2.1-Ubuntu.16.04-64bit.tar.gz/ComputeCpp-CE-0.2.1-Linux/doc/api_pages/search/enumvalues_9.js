var searchData=
[
  ['l1_5fcache',['L1_cache',['../namespacecl_1_1sycl_1_1info.html#a51116d5add442d9bae6028c45e09eca4a84426bc33cb131aa00c40cd629ae5727',1,'cl::sycl::info::L1_cache()'],['../namespacecl_1_1sycl_1_1info.html#a88aea8ff69afd9cf81594eb915690b25a84426bc33cb131aa00c40cd629ae5727',1,'cl::sycl::info::L1_cache()']]],
  ['l2_5fcache',['L2_cache',['../namespacecl_1_1sycl_1_1info.html#a51116d5add442d9bae6028c45e09eca4ac58e8051e3e9607bb653b0d5bcb918e7',1,'cl::sycl::info::L2_cache()'],['../namespacecl_1_1sycl_1_1info.html#a88aea8ff69afd9cf81594eb915690b25ac58e8051e3e9607bb653b0d5bcb918e7',1,'cl::sycl::info::L2_cache()']]],
  ['l3_5fcache',['L3_cache',['../namespacecl_1_1sycl_1_1info.html#a51116d5add442d9bae6028c45e09eca4a4caa8fade30967a8377af50b650cdba4',1,'cl::sycl::info::L3_cache()'],['../namespacecl_1_1sycl_1_1info.html#a88aea8ff69afd9cf81594eb915690b25a4caa8fade30967a8377af50b650cdba4',1,'cl::sycl::info::L3_cache()']]],
  ['l4_5fcache',['L4_cache',['../namespacecl_1_1sycl_1_1info.html#a51116d5add442d9bae6028c45e09eca4a7f52cd07191bbdfc8bf925acf7076ffd',1,'cl::sycl::info::L4_cache()'],['../namespacecl_1_1sycl_1_1info.html#a88aea8ff69afd9cf81594eb915690b25a7f52cd07191bbdfc8bf925acf7076ffd',1,'cl::sycl::info::L4_cache()']]],
  ['linear',['linear',['../namespacecl_1_1sycl.html#a950b8d7ebac6997bb817ffe4f6ecfd9ca9a932b3cb396238423eb2f33ec17d6aa',1,'cl::sycl']]],
  ['local',['local',['../namespacecl_1_1sycl_1_1access.html#a6874ae9aff44c453a412c2adefb1b9f7af5ddaf0ca7929578b408c909429f68f2',1,'cl::sycl::access::local()'],['../namespacecl_1_1sycl_1_1info.html#ad3cf44d11f60b23508e91d1ed61ad001af5ddaf0ca7929578b408c909429f68f2',1,'cl::sycl::info::local()']]],
  ['local_5fmem_5fsize',['local_mem_size',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a735f7e0da765dcc1dfc4d3454a9aba14',1,'cl::sycl::info']]],
  ['local_5fmem_5ftype',['local_mem_type',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a65f9a150cd584ee5dd60ce5450b93ebd',1,'cl::sycl::info']]],
  ['local_5fspace',['local_space',['../namespacecl_1_1sycl_1_1access.html#a1e26dc60d7c93fcc056d6be0c41d1d42a619fb1f3a892c810ac284e01782c8531',1,'cl::sycl::access::local_space()'],['../namespacecl_1_1sycl_1_1access.html#a0b32461aa4a1867f288b640d7fc64fbfa619fb1f3a892c810ac284e01782c8531',1,'cl::sycl::access::local_space()']]],
  ['luminance',['LUMINANCE',['../namespacecl_1_1sycl_1_1image__format.html#a0b7cfe71a12013f3ea26cfff51d42506abe6a1165214b52dbaf158f7a20a186d4',1,'cl::sycl::image_format']]]
];
