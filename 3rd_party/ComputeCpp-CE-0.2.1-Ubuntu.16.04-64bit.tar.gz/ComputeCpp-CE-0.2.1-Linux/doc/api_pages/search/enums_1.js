var searchData=
[
  ['channel_5forder',['channel_order',['../namespacecl_1_1sycl_1_1image__format.html#a0b7cfe71a12013f3ea26cfff51d42506',1,'cl::sycl::image_format']]],
  ['channel_5ftype',['channel_type',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89f',1,'cl::sycl::image_format']]],
  ['context',['context',['../namespacecl_1_1sycl_1_1info.html#a1a5898274a448ac592ebbcee928939c1',1,'cl::sycl::info']]]
];
