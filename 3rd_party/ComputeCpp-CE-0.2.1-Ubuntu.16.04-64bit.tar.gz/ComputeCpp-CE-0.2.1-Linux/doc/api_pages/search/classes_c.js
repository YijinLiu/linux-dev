var searchData=
[
  ['opencl_5fselector',['opencl_selector',['../classcl_1_1sycl_1_1opencl__selector.html',1,'cl::sycl']]]
];
