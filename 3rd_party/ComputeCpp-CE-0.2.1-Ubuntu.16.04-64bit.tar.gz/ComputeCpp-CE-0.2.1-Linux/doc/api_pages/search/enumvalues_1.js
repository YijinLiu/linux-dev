var searchData=
[
  ['bgra',['BGRA',['../namespacecl_1_1sycl_1_1image__format.html#a0b7cfe71a12013f3ea26cfff51d42506a5a1fe3c61c9e2fd6dbbc823589f6e697',1,'cl::sycl::image_format']]],
  ['built_5fin_5fkernels',['built_in_kernels',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5accba6884a1618c6371e7aecc2bc3092d',1,'cl::sycl::info']]]
];
