var searchData=
[
  ['m_5fbuffersize',['m_bufferSize',['../structcl_1_1sycl_1_1device__stream__metadata.html#aacee246787cd7db81103872c770af987',1,'cl::sycl::device_stream_metadata']]],
  ['m_5fcurrentindex',['m_currentIndex',['../structcl_1_1sycl_1_1device__stream__metadata.html#a194840ea543ee24e36179a06d24b883f',1,'cl::sycl::device_stream_metadata']]],
  ['m_5ffallbackqueue',['m_fallbackQueue',['../classcl_1_1sycl_1_1handler.html#aca8ae9b682242271c828237b136d2646',1,'cl::sycl::handler']]],
  ['m_5fimpl',['m_impl',['../classcl_1_1sycl_1_1context.html#ae983b0c1c17fbc2e4bcea545108b60a1',1,'cl::sycl::context::m_impl()'],['../classcl_1_1sycl_1_1device__selector.html#ac83830e11e1b46f36d70e651e9fc498c',1,'cl::sycl::device_selector::m_impl()']]],
  ['m_5fmaxstatementsize',['m_maxStatementSize',['../structcl_1_1sycl_1_1device__stream__metadata.html#a917389dbb4b95aa96be1e834ffbec857',1,'cl::sycl::device_stream_metadata']]],
  ['m_5fmetadata',['m_metadata',['../structcl_1_1sycl_1_1device__stream__container.html#a57e357c1340874905f51bd4348a52c9e',1,'cl::sycl::device_stream_container']]],
  ['m_5fnumkernels',['m_numKernels',['../classcl_1_1sycl_1_1handler.html#ac7bffc7ce382906014d6cfaafb7c75e9',1,'cl::sycl::handler']]],
  ['m_5fparamvec',['m_paramVec',['../classcl_1_1sycl_1_1handler.html#a3d6d146a3f005c5a27e653a5dab16550',1,'cl::sycl::handler']]],
  ['m_5fpointer',['m_pointer',['../structcl_1_1sycl_1_1device__stream__container.html#aad6df5182eb17d4a9b6b6cd7d1bd9299',1,'cl::sycl::device_stream_container']]],
  ['m_5fptr',['m_ptr',['../structcl_1_1sycl_1_1device__stream__ptr.html#aa8d6b91ae57ebbc97e51fc9461a99fdb',1,'cl::sycl::device_stream_ptr']]],
  ['m_5fqueue',['m_queue',['../classcl_1_1sycl_1_1handler.html#a53746faca0e6189185ff0218bbda5f22',1,'cl::sycl::handler']]],
  ['m_5fstreammode',['m_streamMode',['../structcl_1_1sycl_1_1device__stream__metadata.html#ae10590b26812659ec970aab6960763e4',1,'cl::sycl::device_stream_metadata']]],
  ['m_5ftrans',['m_trans',['../classcl_1_1sycl_1_1handler.html#a65cd7a5b02ea526bb946eff87188afa1',1,'cl::sycl::handler']]]
];
