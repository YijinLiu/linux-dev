var searchData=
[
  ['default_5fselector',['default_selector',['../classcl_1_1sycl_1_1default__selector.html',1,'cl::sycl']]],
  ['device',['device',['../classcl_1_1sycl_1_1device.html',1,'cl::sycl']]],
  ['device_5ferror',['device_error',['../classcl_1_1sycl_1_1device__error.html',1,'cl::sycl']]],
  ['device_5fselector',['device_selector',['../classcl_1_1sycl_1_1device__selector.html',1,'cl::sycl']]],
  ['device_5fstream_5fcontainer',['device_stream_container',['../structcl_1_1sycl_1_1device__stream__container.html',1,'cl::sycl']]],
  ['device_5fstream_5fmetadata',['device_stream_metadata',['../structcl_1_1sycl_1_1device__stream__metadata.html',1,'cl::sycl']]],
  ['device_5fstream_5fptr',['device_stream_ptr',['../structcl_1_1sycl_1_1device__stream__ptr.html',1,'cl::sycl']]],
  ['device_5ftype',['device_type',['../structcl_1_1sycl_1_1device__type.html',1,'cl::sycl']]]
];
