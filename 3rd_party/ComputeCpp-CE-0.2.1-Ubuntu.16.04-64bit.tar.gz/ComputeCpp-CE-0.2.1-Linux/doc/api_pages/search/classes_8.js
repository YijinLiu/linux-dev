var searchData=
[
  ['kernel',['kernel',['../classcl_1_1sycl_1_1kernel.html',1,'cl::sycl']]],
  ['kernel_5ferror',['kernel_error',['../classcl_1_1sycl_1_1kernel__error.html',1,'cl::sycl']]]
];
