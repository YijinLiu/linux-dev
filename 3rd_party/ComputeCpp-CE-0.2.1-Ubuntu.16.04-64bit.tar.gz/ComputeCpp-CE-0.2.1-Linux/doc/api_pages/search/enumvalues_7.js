var searchData=
[
  ['half_5ffloat',['HALF_FLOAT',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa394f77ad5c4d4d20b17f354a96f6b82e',1,'cl::sycl::image_format']]],
  ['half_5ffp_5fconfig',['half_fp_config',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5ae274f2a84e5820be22ee7cc505698105',1,'cl::sycl::info']]],
  ['hex',['hex',['../namespacecl_1_1sycl.html#aae8e7aa729b49299771cd464d4b17370ab8d1b43eae73587ba56baef574709ecb',1,'cl::sycl::hex()'],['../namespacecl_1_1sycl.html#ac2cfd4240d2d4a88777e42290022e894ab8d1b43eae73587ba56baef574709ecb',1,'cl::sycl::hex()']]],
  ['host',['host',['../namespacecl_1_1sycl_1_1info.html#a839771ab6b37e25ae67d5c8a2d4d97f8a67b3dba8bc6778101892eb77249db32e',1,'cl::sycl::info']]],
  ['host_5fbuffer',['host_buffer',['../namespacecl_1_1sycl_1_1access.html#a6874ae9aff44c453a412c2adefb1b9f7aa0599d72026e3c6df4a0488cdf4e18d7',1,'cl::sycl::access']]],
  ['host_5fimage',['host_image',['../namespacecl_1_1sycl_1_1access.html#a6874ae9aff44c453a412c2adefb1b9f7ad19909e3ef6decbf2453174616b470c2',1,'cl::sycl::access']]],
  ['host_5funified_5fmemory',['host_unified_memory',['../namespacecl_1_1sycl_1_1info.html#a51f4189fcf4ca86d768d0fcce34d8bc5a0fbdc8bcd6c762ac073157f9e77b2437',1,'cl::sycl::info']]]
];
