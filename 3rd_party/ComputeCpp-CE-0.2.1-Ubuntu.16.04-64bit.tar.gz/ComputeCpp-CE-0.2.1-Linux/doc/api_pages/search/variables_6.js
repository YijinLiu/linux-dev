var searchData=
[
  ['scientific',['scientific',['../namespacecl_1_1sycl.html#a9ba02bcae62fa0909ce6b0cb6d96d8b8',1,'cl::sycl']]],
  ['showbase',['showbase',['../namespacecl_1_1sycl.html#af62681d2137d457c07a6ef2168a2da64',1,'cl::sycl']]],
  ['showpos',['showpos',['../namespacecl_1_1sycl.html#a64e6484bfd8cacee25539897bedfb6a3',1,'cl::sycl']]],
  ['space',['space',['../classcl_1_1sycl_1_1multi__ptr.html#a22d6b7771008a7407c5977e9ef884484',1,'cl::sycl::multi_ptr']]]
];
