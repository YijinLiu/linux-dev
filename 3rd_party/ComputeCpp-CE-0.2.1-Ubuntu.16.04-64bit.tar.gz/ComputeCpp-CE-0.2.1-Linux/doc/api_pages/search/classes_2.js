var searchData=
[
  ['cl_5fexception',['cl_exception',['../structcl_1_1sycl_1_1cl__exception.html',1,'cl::sycl']]],
  ['compile_5fprogram_5ferror',['compile_program_error',['../classcl_1_1sycl_1_1compile__program__error.html',1,'cl::sycl']]],
  ['constant_5fptr',['constant_ptr',['../classcl_1_1sycl_1_1constant__ptr.html',1,'cl::sycl']]],
  ['context',['context',['../classcl_1_1sycl_1_1context.html',1,'cl::sycl']]],
  ['convert_5frelational',['convert_relational',['../structcl_1_1sycl_1_1convert__relational.html',1,'cl::sycl']]],
  ['convert_5frelational_3c_20cl_5fdouble_20_3e',['convert_relational&lt; cl_double &gt;',['../structcl_1_1sycl_1_1convert__relational_3_01cl__double_01_4.html',1,'cl::sycl']]],
  ['convert_5frelational_3c_20cl_5ffloat_20_3e',['convert_relational&lt; cl_float &gt;',['../structcl_1_1sycl_1_1convert__relational_3_01cl__float_01_4.html',1,'cl::sycl']]],
  ['convert_5frelational_3c_20vec_3c_20cl_5fdouble_2c_20width_20_3e_20_3e',['convert_relational&lt; vec&lt; cl_double, width &gt; &gt;',['../structcl_1_1sycl_1_1convert__relational_3_01vec_3_01cl__double_00_01width_01_4_01_4.html',1,'cl::sycl']]],
  ['convert_5frelational_3c_20vec_3c_20cl_5ffloat_2c_20width_20_3e_20_3e',['convert_relational&lt; vec&lt; cl_float, width &gt; &gt;',['../structcl_1_1sycl_1_1convert__relational_3_01vec_3_01cl__float_00_01width_01_4_01_4.html',1,'cl::sycl']]],
  ['cpu_5fselector',['cpu_selector',['../classcl_1_1sycl_1_1cpu__selector.html',1,'cl::sycl']]]
];
