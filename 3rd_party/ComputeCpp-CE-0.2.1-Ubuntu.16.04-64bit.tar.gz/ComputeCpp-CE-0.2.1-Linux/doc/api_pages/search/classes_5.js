var searchData=
[
  ['global_5fptr',['global_ptr',['../classcl_1_1sycl_1_1global__ptr.html',1,'cl::sycl']]],
  ['gpu_5fselector',['gpu_selector',['../classcl_1_1sycl_1_1gpu__selector.html',1,'cl::sycl']]],
  ['group',['group',['../classcl_1_1sycl_1_1group.html',1,'cl::sycl']]]
];
