var searchData=
[
  ['sampler',['sampler',['../classcl_1_1sycl_1_1sampler.html',1,'cl::sycl']]],
  ['stream',['stream',['../classcl_1_1sycl_1_1stream.html',1,'cl::sycl']]],
  ['stream_5fvec',['stream_vec',['../structcl_1_1sycl_1_1stream__vec.html',1,'cl::sycl']]],
  ['stream_5fvec_3c_2016_2c_20true_2c_20elementt_2c_20kdimensions_20_3e',['stream_vec&lt; 16, true, elementT, kDimensions &gt;',['../structcl_1_1sycl_1_1stream__vec_3_0116_00_01true_00_01element_t_00_01k_dimensions_01_4.html',1,'cl::sycl']]],
  ['stream_5fvec_3c_202_2c_20true_2c_20elementt_2c_20kdimensions_20_3e',['stream_vec&lt; 2, true, elementT, kDimensions &gt;',['../structcl_1_1sycl_1_1stream__vec_3_012_00_01true_00_01element_t_00_01k_dimensions_01_4.html',1,'cl::sycl']]],
  ['stream_5fvec_3c_203_2c_20true_2c_20elementt_2c_20kdimensions_20_3e',['stream_vec&lt; 3, true, elementT, kDimensions &gt;',['../structcl_1_1sycl_1_1stream__vec_3_013_00_01true_00_01element_t_00_01k_dimensions_01_4.html',1,'cl::sycl']]],
  ['stream_5fvec_3c_204_2c_20true_2c_20elementt_2c_20kdimensions_20_3e',['stream_vec&lt; 4, true, elementT, kDimensions &gt;',['../structcl_1_1sycl_1_1stream__vec_3_014_00_01true_00_01element_t_00_01k_dimensions_01_4.html',1,'cl::sycl']]],
  ['stream_5fvec_3c_208_2c_20true_2c_20elementt_2c_20kdimensions_20_3e',['stream_vec&lt; 8, true, elementT, kDimensions &gt;',['../structcl_1_1sycl_1_1stream__vec_3_018_00_01true_00_01element_t_00_01k_dimensions_01_4.html',1,'cl::sycl']]],
  ['swizzled_5fvec',['swizzled_vec',['../classcl_1_1sycl_1_1swizzled__vec.html',1,'cl::sycl']]]
];
