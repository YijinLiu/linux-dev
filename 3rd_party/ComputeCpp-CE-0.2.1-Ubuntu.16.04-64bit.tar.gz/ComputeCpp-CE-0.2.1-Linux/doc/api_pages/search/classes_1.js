var searchData=
[
  ['buffer',['buffer',['../classcl_1_1sycl_1_1buffer.html',1,'cl::sycl']]],
  ['buffer_3c_20const_20t_2c_20dimensions_2c_20allocatort_20_3e',['buffer&lt; const T, dimensions, AllocatorT &gt;',['../classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html',1,'cl::sycl']]],
  ['buffer_3c_20t_2c_20dimensions_2c_20cl_3a_3asycl_3a_3amap_5fallocator_3c_20t_20_3e_20_3e',['buffer&lt; T, dimensions, cl::sycl::map_allocator&lt; T &gt; &gt;',['../classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html',1,'cl::sycl']]]
];
