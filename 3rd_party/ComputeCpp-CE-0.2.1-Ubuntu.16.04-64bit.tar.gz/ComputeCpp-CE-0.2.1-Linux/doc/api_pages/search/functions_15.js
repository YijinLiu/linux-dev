var searchData=
[
  ['wait',['wait',['../classcl_1_1sycl_1_1event.html#a4ce1019bb7e0c38e58339d17548e81f7',1,'cl::sycl::event::wait()'],['../classcl_1_1sycl_1_1event.html#afc9e3d1fdab4ea330b611c1c1f3f7bd6',1,'cl::sycl::event::wait(vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#ac46bc8ee7cff0a3f77c7afb7d60184b4',1,'cl::sycl::queue::wait()']]],
  ['wait_5fand_5fthrow',['wait_and_throw',['../classcl_1_1sycl_1_1event.html#af651e36e8780b75a851c7587cc9c05a7',1,'cl::sycl::event::wait_and_throw()'],['../classcl_1_1sycl_1_1event.html#a99ddb8dc66d0806013235012bd904ef7',1,'cl::sycl::event::wait_and_throw(vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#abfa510446db9f4edd0c16270b199a232',1,'cl::sycl::queue::wait_and_throw()']]],
  ['what',['what',['../classcl_1_1sycl_1_1exception.html#a6305512e2ccf91b36569628c771a70e3',1,'cl::sycl::exception']]]
];
