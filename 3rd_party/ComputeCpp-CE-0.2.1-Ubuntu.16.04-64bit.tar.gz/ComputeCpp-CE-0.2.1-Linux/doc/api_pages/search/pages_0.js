var searchData=
[
  ['codeplay_20computecpp_20community_20edition_20beta_20release',['Codeplay ComputeCpp Community Edition Beta Release',['../index.html',1,'']]]
];
