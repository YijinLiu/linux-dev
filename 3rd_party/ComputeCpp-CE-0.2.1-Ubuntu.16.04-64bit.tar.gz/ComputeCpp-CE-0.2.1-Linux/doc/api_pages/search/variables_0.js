var searchData=
[
  ['cgh',['cgh',['../classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a4b5f3d2607d78c527e2cd1d3b34999d2',1,'cl::sycl::codeplay::host_handler']]],
  ['computecpp_5fconvert_5fattr',['COMPUTECPP_CONVERT_ATTR',['../namespacecl_1_1sycl.html#a2db09c1a13daaa1fd1b4f3bb19d6dc87',1,'cl::sycl']]],
  ['computecpp_5fconvert_5fattr_5fplaceholder',['COMPUTECPP_CONVERT_ATTR_PLACEHOLDER',['../namespacecl_1_1sycl.html#aa6aa2a115ff452f4ff71e4cc2de25ea0',1,'cl::sycl']]],
  ['computecpp_5fprivate_5fmemory_5fattr',['COMPUTECPP_PRIVATE_MEMORY_ATTR',['../namespacecl_1_1sycl.html#a9a895a28b80b9ea2875f6827d89f3c49',1,'cl::sycl']]]
];
