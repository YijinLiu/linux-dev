var searchData=
[
  ['shared_5fptr_5fclass',['shared_ptr_class',['../namespacecl_1_1sycl.html#a145741acbe1817e4b03338ffcfd21012',1,'cl::sycl']]],
  ['short16',['short16',['../namespacecl_1_1sycl.html#a14f74677134c71b1e1b8f18c14c72543',1,'cl::sycl']]],
  ['short2',['short2',['../namespacecl_1_1sycl.html#a6f895497d72f2ebfe9179587b2ca5061',1,'cl::sycl']]],
  ['short3',['short3',['../namespacecl_1_1sycl.html#a11d966a68eb77460c8d6aa9384aae9b9',1,'cl::sycl']]],
  ['short4',['short4',['../namespacecl_1_1sycl.html#ace0c68aa51a25eb8f69bf60230a1a018',1,'cl::sycl']]],
  ['short8',['short8',['../namespacecl_1_1sycl.html#abc67915fd8906d80187028543366efc7',1,'cl::sycl']]],
  ['size_5ftype',['size_type',['../classcl_1_1sycl_1_1map__allocator.html#a3a4e82eb9c9665b713202a96e8475516',1,'cl::sycl::map_allocator::size_type()'],['../classcl_1_1sycl_1_1exception__list.html#a9d6a31d12fc0d6a59127ffc118e2177c',1,'cl::sycl::exception_list::size_type()']]],
  ['string_5fclass',['string_class',['../namespacecl_1_1sycl.html#a20186da90261e9302b957e4823179f1b',1,'cl::sycl']]]
];
