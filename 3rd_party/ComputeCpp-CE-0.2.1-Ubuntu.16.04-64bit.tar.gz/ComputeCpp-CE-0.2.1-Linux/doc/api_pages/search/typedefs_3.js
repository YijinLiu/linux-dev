var searchData=
[
  ['device_5fqueue_5fproperties',['device_queue_properties',['../namespacecl_1_1sycl_1_1info.html#abae660ab9e55f797d6a8a02e325f5103',1,'cl::sycl::info']]],
  ['difference_5ftype',['difference_type',['../classcl_1_1sycl_1_1map__allocator.html#ac59f59caadf6cf7275314cbc5440f904',1,'cl::sycl::map_allocator']]],
  ['double16',['double16',['../namespacecl_1_1sycl.html#a26158b645f3db1b2f631be7ab32382b1',1,'cl::sycl']]],
  ['double2',['double2',['../namespacecl_1_1sycl.html#adb0535e31c78aa8fd3236ca2d3c96042',1,'cl::sycl']]],
  ['double3',['double3',['../namespacecl_1_1sycl.html#a89da2ee2d019ada0e89416ce55950808',1,'cl::sycl']]],
  ['double4',['double4',['../namespacecl_1_1sycl.html#a4a1bbcbd91bc345f31a9a21bc18b55f2',1,'cl::sycl']]],
  ['double8',['double8',['../namespacecl_1_1sycl.html#aeca6ace4036380de82d4b74c07151459',1,'cl::sycl']]]
];
