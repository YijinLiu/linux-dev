var searchData=
[
  ['local_5fmem_5ftype',['local_mem_type',['../namespacecl_1_1sycl_1_1info.html#ad3cf44d11f60b23508e91d1ed61ad001',1,'cl::sycl::info']]]
];
