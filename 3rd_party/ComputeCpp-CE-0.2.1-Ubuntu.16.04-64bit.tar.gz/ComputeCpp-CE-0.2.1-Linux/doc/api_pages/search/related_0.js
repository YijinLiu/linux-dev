var searchData=
[
  ['add_5fexception_5fto_5flist',['add_exception_to_list',['../classcl_1_1sycl_1_1exception__list.html#a76b9a09f1c440b7e0bdf581ea1e996f8',1,'cl::sycl::exception_list']]]
];
