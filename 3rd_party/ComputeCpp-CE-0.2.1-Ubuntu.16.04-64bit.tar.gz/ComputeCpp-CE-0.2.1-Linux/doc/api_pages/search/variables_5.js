var searchData=
[
  ['oct',['oct',['../namespacecl_1_1sycl.html#a03bfa43c64b66e8ad041a2bc79a9991a',1,'cl::sycl']]]
];
