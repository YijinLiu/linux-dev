var searchData=
[
  ['pointer',['pointer',['../classcl_1_1sycl_1_1map__allocator.html#a6ee1a06d7a7705ed7c85028cc0959dbc',1,'cl::sycl::map_allocator']]],
  ['pointer_5ft',['pointer_t',['../classcl_1_1sycl_1_1global__ptr.html#a7414ac7c4430cc692ec518863d938817',1,'cl::sycl::global_ptr::pointer_t()'],['../classcl_1_1sycl_1_1local__ptr.html#a55d4ca19ab20912d93e6193d0043182d',1,'cl::sycl::local_ptr::pointer_t()'],['../classcl_1_1sycl_1_1private__ptr.html#ad346011830efdaea82ddfdd655829e24',1,'cl::sycl::private_ptr::pointer_t()'],['../classcl_1_1sycl_1_1constant__ptr.html#abd13f10a5a0569c352481f2a8dd78fdf',1,'cl::sycl::constant_ptr::pointer_t()'],['../classcl_1_1sycl_1_1multi__ptr.html#a2bce156af8c3a735fda2004c9d2a683a',1,'cl::sycl::multi_ptr::pointer_t()']]],
  ['ptrt',['ptrT',['../structcl_1_1sycl_1_1device__type.html#ae6b6bf4345d3f4be41e86b66129400ac',1,'cl::sycl::device_type']]]
];
