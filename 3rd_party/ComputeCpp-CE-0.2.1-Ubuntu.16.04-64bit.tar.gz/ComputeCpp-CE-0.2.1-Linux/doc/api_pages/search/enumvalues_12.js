var searchData=
[
  ['unorm_5fint16',['UNORM_INT16',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa869096739370b6c68179f91408cf5604',1,'cl::sycl::image_format']]],
  ['unorm_5fint8',['UNORM_INT8',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa310b6fbbb7de382121e9ec0ce093681b',1,'cl::sycl::image_format']]],
  ['unorm_5fint_5f101010',['UNORM_INT_101010',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa21ce1bbadcf759f349523c0c236ea412',1,'cl::sycl::image_format']]],
  ['unorm_5fshort_5f555',['UNORM_SHORT_555',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa45ec8aac06b59d98e393e817e6a1b838',1,'cl::sycl::image_format']]],
  ['unorm_5fshort_5f565',['UNORM_SHORT_565',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa91808bf6d9cc82594b33ad8075b4cf4e',1,'cl::sycl::image_format']]],
  ['unsigned_5fint16',['UNSIGNED_INT16',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fabea03608c36653322d138d7e6cb45e6d',1,'cl::sycl::image_format']]],
  ['unsigned_5fint32',['UNSIGNED_INT32',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa9f4c35561e036e08666626268a190e89',1,'cl::sycl::image_format']]],
  ['unsigned_5fint8',['UNSIGNED_INT8',['../namespacecl_1_1sycl_1_1image__format.html#adbaff7794cb3d1bd9f94b904d307d89fa17dac20defe24ea7a2d28f048077332a',1,'cl::sycl::image_format']]],
  ['unsupported',['unsupported',['../namespacecl_1_1sycl_1_1info.html#aa0e3e915db3c3a6049efb595141acfcda723c25877a86786664edc4b643c08a6f',1,'cl::sycl::info::unsupported()'],['../namespacecl_1_1sycl_1_1info.html#a51116d5add442d9bae6028c45e09eca4a723c25877a86786664edc4b643c08a6f',1,'cl::sycl::info::unsupported()']]]
];
