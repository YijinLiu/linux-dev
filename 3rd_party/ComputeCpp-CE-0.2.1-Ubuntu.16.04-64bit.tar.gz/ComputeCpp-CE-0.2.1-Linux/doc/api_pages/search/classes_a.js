var searchData=
[
  ['map_5fallocator',['map_allocator',['../classcl_1_1sycl_1_1map__allocator.html',1,'cl::sycl']]],
  ['memory_5fallocation_5ferror',['memory_allocation_error',['../classcl_1_1sycl_1_1memory__allocation__error.html',1,'cl::sycl']]],
  ['multi_5fptr',['multi_ptr',['../classcl_1_1sycl_1_1multi__ptr.html',1,'cl::sycl']]]
];
