var searchData=
[
  ['wait',['wait',['../classcl_1_1sycl_1_1event.html#a4ce1019bb7e0c38e58339d17548e81f7',1,'cl::sycl::event::wait()'],['../classcl_1_1sycl_1_1event.html#afc9e3d1fdab4ea330b611c1c1f3f7bd6',1,'cl::sycl::event::wait(vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#ac46bc8ee7cff0a3f77c7afb7d60184b4',1,'cl::sycl::queue::wait()']]],
  ['wait_5fand_5fthrow',['wait_and_throw',['../classcl_1_1sycl_1_1event.html#af651e36e8780b75a851c7587cc9c05a7',1,'cl::sycl::event::wait_and_throw()'],['../classcl_1_1sycl_1_1event.html#a99ddb8dc66d0806013235012bd904ef7',1,'cl::sycl::event::wait_and_throw(vector_class&lt; event &gt; &amp;eventList)'],['../classcl_1_1sycl_1_1queue.html#abfa510446db9f4edd0c16270b199a232',1,'cl::sycl::queue::wait_and_throw()']]],
  ['weak_5fptr_5fclass',['weak_ptr_class',['../namespacecl_1_1sycl.html#a8cc65d5e679773a053245819fa2a13de',1,'cl::sycl']]],
  ['what',['what',['../classcl_1_1sycl_1_1exception.html#a6305512e2ccf91b36569628c771a70e3',1,'cl::sycl::exception']]],
  ['width',['width',['../classcl_1_1sycl_1_1vec.html#a8271724defcca4ba70e0611862531134',1,'cl::sycl::vec']]],
  ['write',['write',['../namespacecl_1_1sycl_1_1access.html#ade7472cc9b6db9b3cd47fb9f3bc8c450aefb2a684e4afb7d55e6147fbe5a332ee',1,'cl::sycl::access']]],
  ['write_5fonly',['write_only',['../namespacecl_1_1sycl_1_1info.html#ab45e77b1fd75fd3224ed6ad3f49f24fea2629564984b808cf7e6cfc61a0286d69',1,'cl::sycl::info']]]
];
