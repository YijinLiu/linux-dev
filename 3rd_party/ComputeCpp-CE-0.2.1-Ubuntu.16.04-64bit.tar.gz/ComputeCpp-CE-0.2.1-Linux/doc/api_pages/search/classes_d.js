var searchData=
[
  ['platform',['platform',['../classcl_1_1sycl_1_1platform.html',1,'cl::sycl']]],
  ['platform_5ferror',['platform_error',['../classcl_1_1sycl_1_1platform__error.html',1,'cl::sycl']]],
  ['precision_5fmanipulator',['precision_manipulator',['../classcl_1_1sycl_1_1precision__manipulator.html',1,'cl::sycl']]],
  ['private_5fmemory',['private_memory',['../classcl_1_1sycl_1_1private__memory.html',1,'cl::sycl']]],
  ['private_5fptr',['private_ptr',['../classcl_1_1sycl_1_1private__ptr.html',1,'cl::sycl']]],
  ['profiling_5ferror',['profiling_error',['../classcl_1_1sycl_1_1profiling__error.html',1,'cl::sycl']]],
  ['program',['program',['../classcl_1_1sycl_1_1program.html',1,'cl::sycl']]]
];
