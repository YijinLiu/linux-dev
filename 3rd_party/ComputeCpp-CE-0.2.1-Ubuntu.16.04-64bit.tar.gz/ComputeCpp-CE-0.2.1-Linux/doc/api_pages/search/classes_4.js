var searchData=
[
  ['event',['event',['../classcl_1_1sycl_1_1event.html',1,'cl::sycl']]],
  ['event_5ferror',['event_error',['../classcl_1_1sycl_1_1event__error.html',1,'cl::sycl']]],
  ['exception',['exception',['../classcl_1_1sycl_1_1exception.html',1,'cl::sycl']]],
  ['exception_5flist',['exception_list',['../classcl_1_1sycl_1_1exception__list.html',1,'cl::sycl']]]
];
