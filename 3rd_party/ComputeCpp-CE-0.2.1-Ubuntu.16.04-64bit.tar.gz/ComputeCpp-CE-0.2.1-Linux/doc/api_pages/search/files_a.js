var searchData=
[
  ['nd_5frange_5fbase_2eh',['nd_range_base.h',['../nd__range__base_8h.html',1,'']]]
];
