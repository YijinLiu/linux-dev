var searchData=
[
  ['true_5ft',['true_t',['../namespacecl_1_1sycl_1_1codeplay_1_1access.html#a6789b62da3b1db535905108006ac9852a1b756892a15e10bdbdfe033bf55e8d03',1,'cl::sycl::codeplay::access']]]
];
