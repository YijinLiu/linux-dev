var searchData=
[
  ['kernel',['kernel',['../classcl_1_1sycl_1_1kernel.html#acd8bfcd11f7b88081aa5af2d92d749e1',1,'cl::sycl::kernel::kernel(const kernel &amp;kernel)'],['../classcl_1_1sycl_1_1kernel.html#aa7cb6dcd9c59301285c8ff3a5e85fdb7',1,'cl::sycl::kernel::kernel(cl_kernel clKernel)']]]
];
