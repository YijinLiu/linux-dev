var searchData=
[
  ['element_5ftype',['element_type',['../classcl_1_1sycl_1_1vec.html#a009f0de4acb88a13ea83375a71e47a55',1,'cl::sycl::vec']]],
  ['exception_5fptr',['exception_ptr',['../namespacecl_1_1sycl.html#a6a4702500d2bdd07839eade575d0b4e4',1,'cl::sycl']]]
];
