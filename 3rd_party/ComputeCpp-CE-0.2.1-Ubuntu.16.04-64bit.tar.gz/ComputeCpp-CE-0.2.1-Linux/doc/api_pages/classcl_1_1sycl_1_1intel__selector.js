var classcl_1_1sycl_1_1intel__selector =
[
    [ "intel_selector", "classcl_1_1sycl_1_1intel__selector.html#a65a4d5a83a2b4a4514595eb3086958a4", null ],
    [ "~intel_selector", "classcl_1_1sycl_1_1intel__selector.html#ab3c3f633f6f690fcdeb606cd6d56eb71", null ]
];