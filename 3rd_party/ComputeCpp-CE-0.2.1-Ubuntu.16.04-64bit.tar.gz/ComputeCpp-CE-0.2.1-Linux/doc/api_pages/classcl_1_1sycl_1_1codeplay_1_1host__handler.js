var classcl_1_1sycl_1_1codeplay_1_1host__handler =
[
    [ "host_handler", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#acc93152c17208a613dca7db74727fc17", null ],
    [ "host_task", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a7cb7abf13378541bbaa0ee8f9627deba", null ],
    [ "host_task_impl", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a69fb5bd39f17ba843306316cb77a895b", null ],
    [ "operator cl::sycl::handler &", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a35d4d7a77040ef2b73096236e1c1e8eb", null ],
    [ "operator const cl::sycl::handler &", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a194f2196cd50a00fd8e53362d2d6c995", null ],
    [ "detail::queue", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a73eb26ca6af6cd41619892a536f07ce2", null ],
    [ "queue", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#ab0867b3d911833209f691474b8b2c37b", null ],
    [ "cgh", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html#a4b5f3d2607d78c527e2cd1d3b34999d2", null ]
];