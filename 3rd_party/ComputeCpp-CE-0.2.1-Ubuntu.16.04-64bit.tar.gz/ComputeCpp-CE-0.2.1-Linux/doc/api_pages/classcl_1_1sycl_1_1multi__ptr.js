var classcl_1_1sycl_1_1multi__ptr =
[
    [ "pointer_t", "classcl_1_1sycl_1_1multi__ptr.html#a2bce156af8c3a735fda2004c9d2a683a", null ],
    [ "reference_t", "classcl_1_1sycl_1_1multi__ptr.html#a90827c0f4236e528f993c6f1aee624d6", null ],
    [ "multi_ptr", "classcl_1_1sycl_1_1multi__ptr.html#ac98647f9b66ff3285ddd6ca4fd445006", null ],
    [ "operator pointer_class", "classcl_1_1sycl_1_1multi__ptr.html#a9a95b4c1f3255c64ddebdcef6eb28adb", null ],
    [ "pointer", "classcl_1_1sycl_1_1multi__ptr.html#ad4f8155a73ffd9ac39fe7f3ef48e2538", null ]
];