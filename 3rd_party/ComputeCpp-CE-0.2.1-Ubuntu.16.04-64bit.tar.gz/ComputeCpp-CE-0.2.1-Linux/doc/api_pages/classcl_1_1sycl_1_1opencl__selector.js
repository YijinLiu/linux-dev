var classcl_1_1sycl_1_1opencl__selector =
[
    [ "opencl_selector", "classcl_1_1sycl_1_1opencl__selector.html#ae2f649ab5be0dacec7ff8683bef8ab85", null ],
    [ "~opencl_selector", "classcl_1_1sycl_1_1opencl__selector.html#acc647b1345d16b5d0b35c6bea32d7e0d", null ]
];