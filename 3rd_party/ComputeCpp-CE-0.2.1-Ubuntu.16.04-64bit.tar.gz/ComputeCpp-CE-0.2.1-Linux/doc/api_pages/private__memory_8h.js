var private__memory_8h =
[
    [ "private_memory", "classcl_1_1sycl_1_1private__memory.html", "classcl_1_1sycl_1_1private__memory" ],
    [ "COMPUTECPP_PRIVATE_MEMORY_ATTR", "private__memory_8h.html#a9a895a28b80b9ea2875f6827d89f3c49", null ]
];