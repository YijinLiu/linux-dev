var structcl_1_1sycl_1_1device__type =
[
    [ "ptrT", "structcl_1_1sycl_1_1device__type.html#ae6b6bf4345d3f4be41e86b66129400ac", null ]
];