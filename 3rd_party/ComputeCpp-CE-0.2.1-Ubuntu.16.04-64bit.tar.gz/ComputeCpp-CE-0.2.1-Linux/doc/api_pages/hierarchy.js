var hierarchy =
[
    [ "accessor_base", null, [
      [ "cl::sycl::detail::accessor_common< elemT, kDims, kMode, kTarget, codeplay::access::placeholder::false_t >", null, [
        [ "cl::sycl::accessor< elemT, kDims, kMode, kTarget, isPlaceholder >", "classcl_1_1sycl_1_1accessor.html", null ]
      ] ],
      [ "cl::sycl::detail::accessor_common< elemT, kDims, kMode, kTarget, codeplay::access::placeholder::true_t >", null, [
        [ "cl::sycl::accessor< elemT, kDims, kMode, kTarget, codeplay::access::placeholder::true_t >", "classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_00_01codeplay_1_1ac5c2afbe106fba9f29d1fa9fd216e6b35.html", null ]
      ] ]
    ] ],
    [ "cl::sycl::atomic< T >", "structcl_1_1sycl_1_1atomic.html", null ],
    [ "buffer_mem", null, [
      [ "cl::sycl::buffer< T, dimensions, AllocatorT >", "classcl_1_1sycl_1_1buffer.html", null ],
      [ "cl::sycl::buffer< const T, dimensions, AllocatorT >", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html", null ],
      [ "cl::sycl::buffer< T, dimensions, cl::sycl::map_allocator< T > >", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html", null ]
    ] ],
    [ "cl::sycl::context", "classcl_1_1sycl_1_1context.html", null ],
    [ "cl::sycl::convert_relational< T >", "structcl_1_1sycl_1_1convert__relational.html", null ],
    [ "cl::sycl::convert_relational< cl_double >", "structcl_1_1sycl_1_1convert__relational_3_01cl__double_01_4.html", null ],
    [ "cl::sycl::convert_relational< cl_float >", "structcl_1_1sycl_1_1convert__relational_3_01cl__float_01_4.html", null ],
    [ "cl::sycl::convert_relational< vec< cl_double, width > >", "structcl_1_1sycl_1_1convert__relational_3_01vec_3_01cl__double_00_01width_01_4_01_4.html", null ],
    [ "cl::sycl::convert_relational< vec< cl_float, width > >", "structcl_1_1sycl_1_1convert__relational_3_01vec_3_01cl__float_00_01width_01_4_01_4.html", null ],
    [ "cl::sycl::device", "classcl_1_1sycl_1_1device.html", null ],
    [ "cl::sycl::device_selector", "classcl_1_1sycl_1_1device__selector.html", [
      [ "cl::sycl::amd_selector", "classcl_1_1sycl_1_1amd__selector.html", null ],
      [ "cl::sycl::cpu_selector", "classcl_1_1sycl_1_1cpu__selector.html", null ],
      [ "cl::sycl::default_selector", "classcl_1_1sycl_1_1default__selector.html", null ],
      [ "cl::sycl::gpu_selector", "classcl_1_1sycl_1_1gpu__selector.html", null ],
      [ "cl::sycl::host_selector", "classcl_1_1sycl_1_1host__selector.html", null ],
      [ "cl::sycl::intel_selector", "classcl_1_1sycl_1_1intel__selector.html", null ],
      [ "cl::sycl::opencl_selector", "classcl_1_1sycl_1_1opencl__selector.html", null ]
    ] ],
    [ "cl::sycl::device_stream_container", "structcl_1_1sycl_1_1device__stream__container.html", null ],
    [ "cl::sycl::device_stream_metadata", "structcl_1_1sycl_1_1device__stream__metadata.html", null ],
    [ "cl::sycl::device_stream_ptr", "structcl_1_1sycl_1_1device__stream__ptr.html", null ],
    [ "cl::sycl::device_type< elemT >", "structcl_1_1sycl_1_1device__type.html", null ],
    [ "cl::sycl::event", "classcl_1_1sycl_1_1event.html", null ],
    [ "std::exception", null, [
      [ "std::runtime_error", null, [
        [ "cl::sycl::exception", "classcl_1_1sycl_1_1exception.html", [
          [ "cl::sycl::async_exception", "structcl_1_1sycl_1_1async__exception.html", null ],
          [ "cl::sycl::cl_exception", "structcl_1_1sycl_1_1cl__exception.html", null ],
          [ "cl::sycl::device_error", "classcl_1_1sycl_1_1device__error.html", [
            [ "cl::sycl::compile_program_error", "classcl_1_1sycl_1_1compile__program__error.html", null ],
            [ "cl::sycl::invalid_object_error", "classcl_1_1sycl_1_1invalid__object__error.html", null ],
            [ "cl::sycl::link_program_error", "classcl_1_1sycl_1_1link__program__error.html", null ],
            [ "cl::sycl::memory_allocation_error", "classcl_1_1sycl_1_1memory__allocation__error.html", null ],
            [ "cl::sycl::platform_error", "classcl_1_1sycl_1_1platform__error.html", null ],
            [ "cl::sycl::profiling_error", "classcl_1_1sycl_1_1profiling__error.html", null ]
          ] ],
          [ "cl::sycl::runtime_error", "classcl_1_1sycl_1_1runtime__error.html", [
            [ "cl::sycl::event_error", "classcl_1_1sycl_1_1event__error.html", null ],
            [ "cl::sycl::invalid_parameter_error", "classcl_1_1sycl_1_1invalid__parameter__error.html", null ],
            [ "cl::sycl::kernel_error", "classcl_1_1sycl_1_1kernel__error.html", null ],
            [ "cl::sycl::nd_range_error", "classcl_1_1sycl_1_1nd__range__error.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "cl::sycl::exception_list", "classcl_1_1sycl_1_1exception__list.html", null ],
    [ "group_base", null, [
      [ "cl::sycl::group< dimensions >", "classcl_1_1sycl_1_1group.html", null ]
    ] ],
    [ "cl::sycl::half", "classcl_1_1sycl_1_1half.html", null ],
    [ "cl::sycl::handler", "classcl_1_1sycl_1_1handler.html", [
      [ "cl::sycl::codeplay::handler", "classcl_1_1sycl_1_1codeplay_1_1handler.html", null ]
    ] ],
    [ "cl::sycl::handler_event", "classcl_1_1sycl_1_1handler__event.html", null ],
    [ "cl::sycl::codeplay::host_handler", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html", null ],
    [ "index_array_operators", null, [
      [ "cl::sycl::id< dimensions >", "classcl_1_1sycl_1_1id.html", null ],
      [ "cl::sycl::id< 1 >", "classcl_1_1sycl_1_1id_3_011_01_4.html", null ],
      [ "cl::sycl::id< 2 >", "classcl_1_1sycl_1_1id_3_012_01_4.html", null ],
      [ "cl::sycl::id< 3 >", "classcl_1_1sycl_1_1id_3_013_01_4.html", null ],
      [ "cl::sycl::range< dimensions >", "classcl_1_1sycl_1_1range.html", null ],
      [ "cl::sycl::range< 1 >", "classcl_1_1sycl_1_1range_3_011_01_4.html", null ],
      [ "cl::sycl::range< 2 >", "classcl_1_1sycl_1_1range_3_012_01_4.html", null ],
      [ "cl::sycl::range< 3 >", "classcl_1_1sycl_1_1range_3_013_01_4.html", null ]
    ] ],
    [ "cl::sycl::detail::item_base", null, [
      [ "cl::sycl::item< dimensions >", "classcl_1_1sycl_1_1item.html", null ]
    ] ],
    [ "cl::sycl::kernel", "classcl_1_1sycl_1_1kernel.html", null ],
    [ "cl::sycl::map_allocator< T >", "classcl_1_1sycl_1_1map__allocator.html", null ],
    [ "cl::sycl::detail::mem_container< dataT, kElems, kElems >", null, [
      [ "cl::sycl::vec< dataT, kElems >", "classcl_1_1sycl_1_1vec.html", null ]
    ] ],
    [ "cl::sycl::detail::nd_item_base", null, [
      [ "cl::sycl::nd_item< dimensions >", "classcl_1_1sycl_1_1nd__item.html", null ]
    ] ],
    [ "cl::sycl::detail::nd_range_base", null, [
      [ "cl::sycl::nd_range< dimensions >", "classcl_1_1sycl_1_1nd__range.html", null ]
    ] ],
    [ "cl::sycl::platform", "classcl_1_1sycl_1_1platform.html", null ],
    [ "cl::sycl::precision_manipulator", "classcl_1_1sycl_1_1precision__manipulator.html", null ],
    [ "cl::sycl::detail::private_memory_base< elementT >", null, [
      [ "cl::sycl::private_memory< elementT >", "classcl_1_1sycl_1_1private__memory.html", null ]
    ] ],
    [ "cl::sycl::program", "classcl_1_1sycl_1_1program.html", null ],
    [ "cl::sycl::queue", "classcl_1_1sycl_1_1queue.html", null ],
    [ "cl::sycl::map_allocator< T >::rebind< U >", "structcl_1_1sycl_1_1map__allocator_1_1rebind.html", null ],
    [ "cl::sycl::sampler", "classcl_1_1sycl_1_1sampler.html", null ],
    [ "storage_mem", null, [
      [ "cl::sycl::image_mem", "classcl_1_1sycl_1_1image__mem.html", [
        [ "cl::sycl::image< kDimensions, allocatorT >", "classcl_1_1sycl_1_1image.html", null ]
      ] ]
    ] ],
    [ "cl::sycl::stream", "classcl_1_1sycl_1_1stream.html", null ],
    [ "cl::sycl::stream_vec< kVecPart, kEnabled, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec.html", null ],
    [ "cl::sycl::stream_vec< 16, true, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec_3_0116_00_01true_00_01element_t_00_01k_dimensions_01_4.html", null ],
    [ "cl::sycl::stream_vec< 2, true, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec_3_012_00_01true_00_01element_t_00_01k_dimensions_01_4.html", null ],
    [ "cl::sycl::stream_vec< 3, true, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec_3_013_00_01true_00_01element_t_00_01k_dimensions_01_4.html", null ],
    [ "cl::sycl::stream_vec< 4, true, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec_3_014_00_01true_00_01element_t_00_01k_dimensions_01_4.html", null ],
    [ "cl::sycl::stream_vec< 8, true, elementT, kDimensions >", "structcl_1_1sycl_1_1stream__vec_3_018_00_01true_00_01element_t_00_01k_dimensions_01_4.html", null ],
    [ "swizzled_vec_intermediate", null, [
      [ "cl::sycl::swizzled_vec< dataT, kElems, kIndexesN >", "classcl_1_1sycl_1_1swizzled__vec.html", null ]
    ] ],
    [ "cl::sycl::detail::vec_ptr_class_base< dataType, asp, ptr_class_base< dataType, asp > >", null, [
      [ "cl::sycl::detail::ptr_class_base< dataType, cl::sycl::access::address_space::constant_space >", null, [
        [ "cl::sycl::constant_ptr< dataType >", "classcl_1_1sycl_1_1constant__ptr.html", null ]
      ] ],
      [ "cl::sycl::detail::ptr_class_base< dataType, cl::sycl::access::address_space::global_space >", null, [
        [ "cl::sycl::global_ptr< dataType >", "classcl_1_1sycl_1_1global__ptr.html", null ]
      ] ],
      [ "cl::sycl::detail::ptr_class_base< dataType, cl::sycl::access::address_space::local_space >", null, [
        [ "cl::sycl::local_ptr< dataType >", "classcl_1_1sycl_1_1local__ptr.html", null ]
      ] ],
      [ "cl::sycl::detail::ptr_class_base< dataType, cl::sycl::access::address_space::private_space >", null, [
        [ "cl::sycl::private_ptr< dataType >", "classcl_1_1sycl_1_1private__ptr.html", null ]
      ] ],
      [ "cl::sycl::detail::ptr_class_base< dataType, Space >", null, [
        [ "cl::sycl::multi_ptr< dataType, Space >", "classcl_1_1sycl_1_1multi__ptr.html", null ]
      ] ]
    ] ]
];