var structcl_1_1sycl_1_1cl__exception =
[
    [ "cl_exception", "structcl_1_1sycl_1_1cl__exception.html#a81f7e79a15c250da14110069d7c3cdb7", null ],
    [ "get_cl_code", "structcl_1_1sycl_1_1cl__exception.html#a90990c4e29b280e2b7cad4ce75eeeffc", null ],
    [ "get_cl_error_message", "structcl_1_1sycl_1_1cl__exception.html#ae88497196e80c83b30e425ee61a295f5", null ]
];