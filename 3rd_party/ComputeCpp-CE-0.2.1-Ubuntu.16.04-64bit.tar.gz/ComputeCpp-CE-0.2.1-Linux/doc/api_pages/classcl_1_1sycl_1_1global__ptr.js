var classcl_1_1sycl_1_1global__ptr =
[
    [ "pointer_t", "classcl_1_1sycl_1_1global__ptr.html#a7414ac7c4430cc692ec518863d938817", null ],
    [ "reference_t", "classcl_1_1sycl_1_1global__ptr.html#af1d6ce8687d14547a2ff69ec73368369", null ],
    [ "global_ptr", "classcl_1_1sycl_1_1global__ptr.html#a98140db100b386ac3e777945ac107fcc", null ],
    [ "global_ptr", "classcl_1_1sycl_1_1global__ptr.html#a162f46517e7120952898bd71ceb6c680", null ]
];