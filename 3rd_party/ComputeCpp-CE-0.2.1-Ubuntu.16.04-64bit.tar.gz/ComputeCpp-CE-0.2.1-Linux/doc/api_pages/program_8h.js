var program_8h =
[
    [ "program", "classcl_1_1sycl_1_1program.html", "classcl_1_1sycl_1_1program" ],
    [ "program", "program_8h.html#a6645cc5581516494ff2409d887258574", [
      [ "reference_count", "program_8h.html#a6645cc5581516494ff2409d887258574a40d852658166dc8a786c23023cb20f92", null ],
      [ "context", "program_8h.html#a6645cc5581516494ff2409d887258574a5c18ef72771564b7f43c497dc507aeab", null ],
      [ "devices", "program_8h.html#a6645cc5581516494ff2409d887258574ae0212e54ec3a2a120ca0d321b3a60c78", null ]
    ] ]
];