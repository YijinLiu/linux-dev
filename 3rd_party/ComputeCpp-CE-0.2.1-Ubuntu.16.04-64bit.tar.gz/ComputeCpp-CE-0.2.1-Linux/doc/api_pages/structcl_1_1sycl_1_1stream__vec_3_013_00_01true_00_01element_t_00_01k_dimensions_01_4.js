var structcl_1_1sycl_1_1stream__vec_3_013_00_01true_00_01element_t_00_01k_dimensions_01_4 =
[
    [ "operator()", "structcl_1_1sycl_1_1stream__vec_3_013_00_01true_00_01element_t_00_01k_dimensions_01_4.html#a2a9ed225385f7214dad3f7b74636983d", null ]
];