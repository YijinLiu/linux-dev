var classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4 =
[
    [ "const_reference", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ae4fdbcef0a612aba5e69da53323f60da", null ],
    [ "reference", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ad1a45764235ea9d06cad8e029c36bfa3", null ],
    [ "value_type", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aa529fdd56b9e651dc9137712c049d928", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a58a2032e0ae98b3a95070d79e5f1919b", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a117a04483aa0f22439938fa3ba567754", null ],
    [ "~buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a5a95b04d536aa24fd7eccd434ce113db", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a72ed1dee54a74e220e484fab83d97cbe", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aee07d5c5943b30defaa546806e75a3ec", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ae436b6c1b3cf7638174560c89ce45d94", null ]
];