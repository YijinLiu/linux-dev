var NAVTREE =
[
  [ "Codeplay ComputeCpp", "index.html", [
    [ "Codeplay ComputeCpp Community Edition Beta Release", "index.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Functions", "namespacemembers_func.html", "namespacemembers_func" ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"abacus__types_8h.html",
"classcl_1_1sycl_1_1device__selector.html#ac83830e11e1b46f36d70e651e9fc498c",
"classcl_1_1sycl_1_1program.html#a1525bc29a679c721e46476f2c708c0ab",
"common_8h.html#a137610666a25428027b505d0b4d98fd0",
"host__common__builtins_8h.html#a65553eb5f2c3b957a20f8036ec9393f2",
"host__fp__math__builtins_8h.html#a27d5754122fb749d3e99945cee359d8e",
"host__fp__math__builtins_8h.html#a512a14394cc05dee2d315767f1e30497",
"host__fp__math__builtins_8h.html#a7ddc8dd4f9625545234568767271fb69",
"host__fp__math__builtins_8h.html#aab5be9d6f73c5a50bc31471a25557ee8",
"host__fp__math__builtins_8h.html#ad7fcae3db9e2f594324a66f2c28380ff",
"host__integer__builtins_8h.html#a210f642e80df00085d395cdba3f78617",
"namespacemembers_func.html",
"vec__types__defines_8h.html#a2e8e2e6accd5343f52a8cc44a8d7beac"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';