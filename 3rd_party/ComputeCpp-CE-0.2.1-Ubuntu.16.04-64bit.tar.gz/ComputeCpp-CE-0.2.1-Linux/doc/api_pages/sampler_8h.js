var sampler_8h =
[
    [ "sampler", "classcl_1_1sycl_1_1sampler.html", "classcl_1_1sycl_1_1sampler" ],
    [ "sampler_addressing_mode", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abe", [
      [ "none", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abea334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "clamp_to_edge", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abea7ff5ead6fef18ca5f63119754ac76c3e", null ],
      [ "clamp", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abeaa597a055c00d084069e4bb23dc789ac9", null ],
      [ "repeat", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abea32cf6da134a8b268cf4ab6b79a9a5ad9", null ],
      [ "mirrored_repeat", "sampler_8h.html#a4eaaf3179cfb8483148b5dd859ec1abea301defc6e7425fc63ef35c7827d43b44", null ]
    ] ],
    [ "sampler_filter_mode", "sampler_8h.html#a950b8d7ebac6997bb817ffe4f6ecfd9c", [
      [ "nearest", "sampler_8h.html#a950b8d7ebac6997bb817ffe4f6ecfd9cad879c351426770bc0b13c3628db1e636", null ],
      [ "linear", "sampler_8h.html#a950b8d7ebac6997bb817ffe4f6ecfd9ca9a932b3cb396238423eb2f33ec17d6aa", null ]
    ] ]
];