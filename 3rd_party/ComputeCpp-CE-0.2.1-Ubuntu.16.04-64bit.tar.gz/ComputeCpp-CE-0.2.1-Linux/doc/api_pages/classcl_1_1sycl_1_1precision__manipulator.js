var classcl_1_1sycl_1_1precision__manipulator =
[
    [ "precision_manipulator", "classcl_1_1sycl_1_1precision__manipulator.html#aafc3585d3d4578b1eb7df00e3b63fd43", null ],
    [ "get_precision", "classcl_1_1sycl_1_1precision__manipulator.html#aab1e994ec3e5c7dd4b13e289e1113cec", null ]
];