var kernel_8h =
[
    [ "kernel", "classcl_1_1sycl_1_1kernel.html", "classcl_1_1sycl_1_1kernel" ],
    [ "kernel", "kernel_8h.html#a9845a480a36d09200c5355a775fc1fa1", [
      [ "reference_count", "kernel_8h.html#a9845a480a36d09200c5355a775fc1fa1a40d852658166dc8a786c23023cb20f92", null ],
      [ "num_args", "kernel_8h.html#a9845a480a36d09200c5355a775fc1fa1a036d0146be89deaf4254f17edaaefd45", null ],
      [ "function_name", "kernel_8h.html#a9845a480a36d09200c5355a775fc1fa1ae82f83ed7c80ba9065e07ee379ce7a56", null ],
      [ "attributes", "kernel_8h.html#a9845a480a36d09200c5355a775fc1fa1a736b91750e516139acc13c5eb6564f92", null ]
    ] ]
];