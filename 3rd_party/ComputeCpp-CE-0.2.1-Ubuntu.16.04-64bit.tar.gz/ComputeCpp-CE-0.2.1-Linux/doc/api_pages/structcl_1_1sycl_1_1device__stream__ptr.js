var structcl_1_1sycl_1_1device__stream__ptr =
[
    [ "m_ptr", "structcl_1_1sycl_1_1device__stream__ptr.html#aa8d6b91ae57ebbc97e51fc9461a99fdb", null ]
];