var structcl_1_1sycl_1_1stream__vec =
[
    [ "operator()", "structcl_1_1sycl_1_1stream__vec.html#ad4ddb8c521b10c86a0a3c4283f2d8d7e", null ]
];