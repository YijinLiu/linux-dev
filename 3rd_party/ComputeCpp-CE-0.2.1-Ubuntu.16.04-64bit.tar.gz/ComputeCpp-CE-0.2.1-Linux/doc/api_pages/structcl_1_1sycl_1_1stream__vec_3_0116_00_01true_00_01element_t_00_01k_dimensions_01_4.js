var structcl_1_1sycl_1_1stream__vec_3_0116_00_01true_00_01element_t_00_01k_dimensions_01_4 =
[
    [ "operator()", "structcl_1_1sycl_1_1stream__vec_3_0116_00_01true_00_01element_t_00_01k_dimensions_01_4.html#ad33944a3e30359ea6f8c2ae552269f68", null ]
];