var classcl_1_1sycl_1_1gpu__selector =
[
    [ "gpu_selector", "classcl_1_1sycl_1_1gpu__selector.html#a1fb5acaebca5688f85dd2c68472be06e", null ],
    [ "~gpu_selector", "classcl_1_1sycl_1_1gpu__selector.html#afdb829af6985605c7868ce30bbe2a6ae", null ]
];