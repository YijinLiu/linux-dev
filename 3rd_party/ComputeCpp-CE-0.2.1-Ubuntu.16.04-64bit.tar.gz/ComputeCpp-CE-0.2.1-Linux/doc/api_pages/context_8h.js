var context_8h =
[
    [ "context", "classcl_1_1sycl_1_1context.html", "classcl_1_1sycl_1_1context" ],
    [ "gl_context_interop", "context_8h.html#a5175660b1ec299ffb370f7e8c56a5b16", null ],
    [ "context", "context_8h.html#a1a5898274a448ac592ebbcee928939c1", [
      [ "reference_count", "context_8h.html#a1a5898274a448ac592ebbcee928939c1a40d852658166dc8a786c23023cb20f92", null ],
      [ "num_devices", "context_8h.html#a1a5898274a448ac592ebbcee928939c1abf324a81d4e115643691b7aa4cc12828", null ],
      [ "devices", "context_8h.html#a1a5898274a448ac592ebbcee928939c1ae0212e54ec3a2a120ca0d321b3a60c78", null ],
      [ "gl_interop", "context_8h.html#a1a5898274a448ac592ebbcee928939c1a9d19ae6573a7d4f99ebc6818a92687f5", null ]
    ] ]
];