var structcl_1_1sycl_1_1stream__vec_3_014_00_01true_00_01element_t_00_01k_dimensions_01_4 =
[
    [ "operator()", "structcl_1_1sycl_1_1stream__vec_3_014_00_01true_00_01element_t_00_01k_dimensions_01_4.html#a764e5bd2a5923e9a2c6f3f738431b1b8", null ]
];