var classcl_1_1sycl_1_1half =
[
    [ "half", "classcl_1_1sycl_1_1half.html#a93d9f22b21ecda6a0d75a923b3160d87", null ],
    [ "half", "classcl_1_1sycl_1_1half.html#a329890ccc1079e532bf50b4524b61678", null ],
    [ "operator float", "classcl_1_1sycl_1_1half.html#a3f79fc75ffaf2db0e1116472d99d8097", null ]
];