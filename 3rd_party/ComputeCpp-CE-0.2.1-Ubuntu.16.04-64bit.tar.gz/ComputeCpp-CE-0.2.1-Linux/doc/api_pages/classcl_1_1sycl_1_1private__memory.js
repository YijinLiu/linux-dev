var classcl_1_1sycl_1_1private__memory =
[
    [ "private_memory", "classcl_1_1sycl_1_1private__memory.html#ab0203da35fb879d06ebe41e60097b74a", null ],
    [ "operator()", "classcl_1_1sycl_1_1private__memory.html#af3bc6e695ca59333ccd75ae047cae6f6", null ]
];