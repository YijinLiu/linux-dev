var classcl_1_1sycl_1_1host__selector =
[
    [ "host_selector", "classcl_1_1sycl_1_1host__selector.html#a17b566b5857b2a474c6787251669f849", null ],
    [ "~host_selector", "classcl_1_1sycl_1_1host__selector.html#aa0ad6d02b17d3884c4a736e5d12566ec", null ]
];