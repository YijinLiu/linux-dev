var classcl_1_1sycl_1_1handler__event =
[
    [ "get_complete", "classcl_1_1sycl_1_1handler__event.html#aea5dce183dc0c01759e3cb58efe987e9", null ],
    [ "get_end", "classcl_1_1sycl_1_1handler__event.html#a3728a5eea2b8d09130a0416ff0898300", null ],
    [ "get_kernel", "classcl_1_1sycl_1_1handler__event.html#a6ebd429751f270de51575185956d1a4c", null ]
];