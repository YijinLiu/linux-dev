var classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4 =
[
    [ "const_reference", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a8eb61824ad93587895edb6e7a121d06c", null ],
    [ "reference", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a2ec72f3f23494ba5a5c63224ec34de5f", null ],
    [ "value_type", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#abdea25184702f14530ae71dd0af210a9", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#afb953cb0b14dc82c52019cbddb3bfff3", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a16f39b4b35a8c9b84d9e9f0063ee4fbb", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a1793f15bb9482d4dd45b33719b541525", null ],
    [ "~buffer", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a6cbc4da78e98e480a961e53c4ee12411", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a74c7eccdfb94079b1b177b047668dc00", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a09f9cdd672d8ac1b4cf3f6b3d7b2952f", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01_t_00_01dimensions_00_01cl_1_1sycl_1_1map__allocator_3_01_t_01_4_01_4.html#a28e5975680be8087d6ed9ed4dac1e171", null ]
];