var classcl_1_1sycl_1_1amd__selector =
[
    [ "amd_selector", "classcl_1_1sycl_1_1amd__selector.html#af8c9970d9214bd088fae4e73f582aa20", null ],
    [ "~amd_selector", "classcl_1_1sycl_1_1amd__selector.html#a2d70ad51286e8de181a79c24d4e7578a", null ]
];